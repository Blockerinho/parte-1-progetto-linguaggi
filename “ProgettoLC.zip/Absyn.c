#include <stdio.h>
#include <stdlib.h>

#include "Absyn.h"

Value make_ValueInt(int val)
{
    Value tmp = (Value) malloc(sizeof(*tmp));
    if (!tmp)
    {
        fprintf(stderr, "Error: out of memory when allocating ValueInt!\n");
        exit(1);
    }
    tmp->kind = is_ValueInt;
    tmp->value_int = val;
    return tmp;
}

Value make_ValueBool(int val)
{
    Value tmp = (Value) malloc(sizeof(*tmp));
    if (!tmp)
    {
        fprintf(stderr, "Error: out of memory when allocating ValueBool!\n");
        exit(1);
    }
    tmp->kind = is_ValueBool;
    if (val) {
      tmp->value_bool = 1;
    } else {
      tmp->value_bool = 0;
    }
    return tmp;
}

Value make_ValueString(char* val)
{
    Value tmp = (Value) malloc(sizeof(*tmp));
    if (!tmp)
    {
        fprintf(stderr, "Error: out of memory when allocating ValueString!\n");
        exit(1);
    }
    tmp->kind = is_ValueString;
    tmp->value_string = val;
    return tmp;
}

Value make_ValueLocal(char* field_name)
{
    Value tmp = (Value) malloc(sizeof(*tmp));
    if (!tmp)
    {
        fprintf(stderr, "Error: out of memory when allocating ValueNonLoc!\n");
        exit(1);
    }
    tmp->kind = is_ValueLocal;
    tmp->value_local = field_name;
    return tmp;
}

Value make_ValueNonLocal(char* section_name, char* field_name)
{
    Value tmp = (Value) malloc(sizeof(*tmp));
    if (!tmp)
    {
        fprintf(stderr, "Error: out of memory when allocating ValueNonLoc!\n");
        exit(1);
    }
    tmp->kind = is_ValueNonLocal;
    tmp->value_nonlocal.section_name = section_name;
    tmp->value_nonlocal.field_name = field_name;
    return tmp;
}

void free_Value(Value p)
{
  switch(p->kind)
  {
  case is_ValueInt:
    break;

  case is_ValueBool:
    break;

  case is_ValueString:
    free(p->value_string);
    break;

  case is_ValueLocal:
    free(p->value_local);
    break;

  case is_ValueNonLocal:
    free(p->value_nonlocal.section_name);
    free(p->value_nonlocal.field_name);
    break;
  }
  free(p);
}

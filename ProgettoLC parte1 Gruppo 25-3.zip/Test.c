#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Parser.h"
#include "Absyn.h"
#include "ParserSupport.h"

void usage(void) {
  printf("usage: Call with one of the following argument combinations:\n");
  printf("\t--help\t\tDisplay this help message.\n");
  printf("\t(no arguments)\tParse stdin verbosely.\n");
  printf("\t(files)\t\tParse content of files verbosely.\n");
  printf("\t-s (files)\tSilent mode. Parse content of files silently.\n");
}

int main(int argc, char ** argv)
{
  FILE *input;
  int quiet = 0;
  char *filename = NULL;

  if (argc > 1) {
    if (strcmp(argv[1], "-s") == 0) {
      quiet = 1;
      if (argc > 2) {
        filename = argv[2];
      } else {
        input = stdin;
      }
    } else {
      filename = argv[1];
    }
  }

  section_entry* bindings = NULL;
  if (filename) {
    pnSourceFile(filename, &bindings);
    if (!input) {
      usage();
      exit(1);
    }
  }
  else {
    pSourceFile(stdin, &bindings);
  }

  if (bindings) {
    print_bindings(bindings);
    return 0;
  }
  return 1;
}

